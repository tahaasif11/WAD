<!DOCTYPE html>
<html>
<head>
	<title></title>

</head>
<body>

	<form action="new.php" method="POST">

		<h1>Sign Up</h1>
		
		Name
        <input type="text" name="stdname" id="stdname" placeholder="Enter your Name"> <br><br>

        Age
        <input type="number" name="Age" id="Age" placeholder="Enter your age"> <br><br>

        Email
        <input type="text" name="mail" id="mail" placeholder="Enter your email"> <br><br>

        Password
        <input type="password" name="password" id="password" placeholder="Enter your password"> <br><br>

        Confirm Password
        <input type="password" name="cpassword" id="cpassword" placeholder="Confirm your password"> <br><br>

        
        <input type="submit" name="submit" value="submit"> 
        <input type="reset" name="reset" value="reset"> 
          
          

	</form>
</body>
</html>