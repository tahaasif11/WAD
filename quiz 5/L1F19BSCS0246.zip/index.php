<!DOCTYPE html>
<html>
<head>
	<title></title>
	
	</script>
</head>
<body>

	<form action="new1.php" method="POST">

		<h1>Login</h1>
		
		Email
        <input type="text" name="mail" id="mail" placeholder="Enter your email"> <br><br>
        Password
        <input type="password" name="password" id="password" placeholder="Enter your password"> <br><br>
        
        <input type="submit" name="submit" value="submit"> 
        <input type="reset" name="reset" value="reset"> 

	</form>
</body>
</html>